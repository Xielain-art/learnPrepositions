import Podtable from './podtable'

/**
 * Export podtable
 */
export default Podtable